from kbeutils import avl
from parapy.gui import display
from kbeutils.Tutorial_7_exercise_ver3.Tutorial_7_exercise.aircraft import Aircraft
from parapy.core import *


class AvlAnalysis(avl.Interface):
    aircraft = Input(in_tree=True)
    case_settings = Input()

    @action(label="Call Me!")
    def call_me(self):
        print("I was triggered in GUI")

    @Attribute
    def configuration(self):
        return self.aircraft.avl_configuration

    @Part
    def cases(self):
        return avl.Case(quantify=len(self.case_settings),
                        name=self.case_settings[child.index][0],
                        settings=self.case_settings[child.index][1])

    @Attribute
    def l_over_d(self):
        return {case_name: result['Totals']['CLtot'] / result['Totals']['CDtot']
                for case_name, result in self.results.items()}


if __name__ == '__main__':
    aircraft = Aircraft(label="fast primi plane",
                        length=16,
                        slenderness=12,
                        wing_location=0.42,
                        wing_area=50,
                        wing_aspect_ratio=2.5,
                        wing_taper_ratio=0.2,
                        wing_le_sweep=46,
                        twist=-5,
                        wing_airfoil='35008',
                        elevator_hinge=0.8,
                        tail_area=8,
                        tail_aspect_ratio=2,
                        tail_taper_ratio=0.2,
                        tail_airfoil='0012',
                        rudder_hinge=0.6,
                        mach=0.5
                        )
    # display(aircraft)

    cases = [('fixed_aoa', {'alpha': 3}),  # aircraft flown at constant angle of attack
             ('fixed_cl', {'alpha': avl.Parameter(name='alpha', value=0.3, setting='CL')}),  #
             # aircraft is flown at a given Cl. AVL will find the necessary angle of attack
             ('trimmed', {'alpha': 3,  # aircraft is trimmed (Cm=0) at an angle of attack of 3
                          # degrees using the elevator
                          'elevator': avl.Parameter(name='elevator',
                                                    value=0.0,
                                                    setting='Cm')})
             ]

    analysis = AvlAnalysis(aircraft=aircraft,
                           case_settings=cases)  # the 3 cases above are executed
    display(analysis)


