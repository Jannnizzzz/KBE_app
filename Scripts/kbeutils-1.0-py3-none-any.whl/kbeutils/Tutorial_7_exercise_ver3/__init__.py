#!/usr/bin/env python
# encoding: utf-8
#
# Copyright (c) 2019 Akshay Raju Kulkarni
#
# This code is subject to a Non-Disclosure Agreement. You have received a
# temporary copy of the code for non-commercial, educational purposes only.
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
# EITHER EXPRESSED OR  IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
