""" AVL interface
"""

import os.path

from parapy.core import Base, Attribute, Input
from parapy.core.decorators import action

import avlwrapper

from kbeutils.globs import ICON_DIR, BIN_DIR


def _get_wrapper_object(obj):
    if obj is not None:
        return obj.wrapper_object
    else:
        return None


class Case(Base):
    #: case name
    #: :type:
    name = Input()

    #: case-specific inputs. key=value pairs where `key` is the name of the
    #:  modified parameter or state and value is either a float or a Parameter
    #: :type: dict
    settings = Input({})

    @Attribute
    def _wrapper_arguments(self):
        args = {}
        for key, value in self.settings.items():
            if isinstance(value, Parameter):
                value = value.wrapper_object
            args[key] = value
        return args

    @Attribute
    def parameters(self):
        return [Parameter(name=key,
                          value=param.value,
                          setting=param.setting)
                for key, param in self.wrapper_object.parameters.items()]

    @Attribute
    def states(self):
        states = {}
        for name, state in self.wrapper_object.states.items():
            states[name] = state.value
        return states

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Case(name=self.name, **self._wrapper_arguments)


class Parameter(Base):
    #: parameter name
    #: :type: str
    name = Input()

    #: parameter value
    #: :type: float
    value = Input()

    # parameter setting
    #: :type: str or None
    setting = Input(None)

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Parameter(name=self.name,
                                    value=self.value,
                                    setting=self.setting)


class Interface(Base):
    """AVL interface"""

    __icon__ = os.path.join(ICON_DIR, 'avl_logo.png')

    configuration = Input()
    cases = Input([Case(name='default')])

    @Input
    def run_cmds(self):
        return self.wrapper_object._run_all_cases_cmds

    @Attribute
    def wrapper_object(self):
        session = avlwrapper.Session(geometry=_get_wrapper_object(
            self.configuration),
            cases=[_get_wrapper_object(obj)
                   for obj in self.cases])
        session.config['avl_bin'] = os.path.join(BIN_DIR, 'avl.exe')
        return session

    @Attribute
    def results(self):
        pre_fn = self.wrapper_object._write_analysis_files
        post_fn = self.wrapper_object._read_results
        return self.wrapper_object.run_avl(cmds=self.run_cmds,
                                           pre_fn=pre_fn,
                                           post_fn=post_fn)

    @action(label='Show geometry in AVL',
            icon=os.path.join(ICON_DIR, 'avl_configuration.png'))
    def show_geometry(self):
        self.wrapper_object.show_geometry()

    @action(label='Show Trefftz plots')
    def show_trefftz_plot(self):
        for idx in range(1, len(self.cases) + 1):
            self.wrapper_object.show_trefftz_plot(idx)
