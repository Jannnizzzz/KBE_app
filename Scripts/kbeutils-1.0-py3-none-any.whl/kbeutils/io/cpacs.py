import math

import numpy as np

from parapy.geom import Point, rotate, XOY, Position


def add_transformations(transformation1, transformation2):

    total_transformation = dict()
    total_transformation['scaling'] = add_scalings(transformation1['scaling'],
                                                   transformation2['scaling'])
    total_transformation['rotation'] = add_rotations(transformation1['rotation'],
                                                     transformation2['rotation'])
    total_transformation['translation'] = add_translations(transformation1['translation'],
                                                           transformation2['translation'],
                                                           transformation2['translationType'],
                                                           total_transformation['rotation'])
    return total_transformation


def add_scalings(scaling1, scaling2):

    return [scaling1[i]*scaling2[i] for i in range(len(scaling1))]


def add_rotations(rotation1, rotation2):

    # Get orientation after the two rotations
    orientation = rotate_xyz(rotate_xyz(XOY, rotation1), rotation2).orientation
    # Get rotation matrix and calculate corresponding euler angles
    rotation_matrix = np.array(zip(*orientation))
    euler_angles = rotation_matrix_to_euler(rotation_matrix)

    return euler_angles


def add_translations(translation1, translation2, translation_type, rotation=None):

    if translation_type == 'absGlobal':
        tot_translation = [translation1[i]+translation2[i] for i in range(len(translation1))]
    elif translation_type == 'absLocal':
        # Get local orientation of local reference frame
        local_ref = rotate_xyz(XOY, rotation)
        # Translate local reference frame
        translated_ref = local_ref.translate(x=translation2[0],
                                             y=translation2[1],
                                             z=translation2[2])
        # Add both translation
        tot_translation = [translation1[i] + translated_ref[i] for i in range(3)]
    elif translation_type == 'relative':
        raise NotImplementedError
    return tot_translation


def rotate_xyz(initial_orientation, rotation):

    return rotate(rotate(rotate(initial_orientation, 'x', rotation[0], deg=True),
                         'y', rotation[1], deg=True),
                  'z', rotation[2], deg=True)


def rotation_matrix_to_euler(rotation_matrix):

    if rotation_matrix[0, 2] == -1:
        x = -math.atan2(rotation_matrix[1, 0], rotation_matrix[1, 1])
        y = -math.pi / 2
        z = 0
    elif rotation_matrix[0, 2] == 1:
        x = math.atan2(rotation_matrix[1, 0], rotation_matrix[1, 1])
        y = math.pi/2
        z = 0
    else:
        x = math.atan2(-rotation_matrix[1, 2], rotation_matrix[2, 2])
        y = math.asin(rotation_matrix[0, 2])
        z = math.atan2(-rotation_matrix[0, 1], rotation_matrix[0, 0])

    x = math.degrees(x)
    y = math.degrees(y)
    z = math.degrees(z)

    return [x, y, z]


def positioning_to_translation(positioning):

    sweep, dihedral, length = positioning['sweep'], positioning['dihedral'], positioning['length']

    return rotate(rotate(Point(0, length, 0), 'x', dihedral, deg=True), 'z', -sweep, deg=True)


def transform_points(points, transformation):

    return translate_points(rotate_points(scale_points(points, transformation['scaling']),
                                          transformation['rotation']),
                            transformation['translation'])


def scale_points(points, scaling):

    return [Point(x*scaling[0], y*scaling[1], z*scaling[2]) for x, y, z in points]


def rotate_points(points, rotation):

    return [rotate(rotate(rotate(pt, 'x', rotation[0], deg=True),
                          'y', rotation[1], deg=True),
                   'z', rotation[2], deg=True) for pt in points]


def translate_points(points, translation):

    return [pt.translate(x=translation[0], y=translation[1], z=translation[2]) for pt in points]


def get_location(transformation):
    """ Get the location with respect to the global reference system based on the given transformation """

    return transform_points([[0, 0, 0]], transformation)[0]


def get_orientation(transformation):
    """ Get the orientation with respect to the global reference system based on the given transformation"""

    return rotate_xyz(XOY, transformation['rotation']).orientation


def get_position(transformation):

    return Position(location=get_location(transformation),
                    orientation=get_orientation(transformation))
