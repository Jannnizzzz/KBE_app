import os.path
import numpy as np

from xml.etree import ElementTree as ET

from parapy.core import Attribute, Input, Part, Base, child, DynamicType
from parapy.core.decorators import action
from parapy.core.meta import Undefined
from parapy.geom import Point, XOY

from kbeutils.globs import ICON_DIR
from kbeutils.gui.dialogs import FileSaveDialog
from kbeutils.io.cpacs import add_transformations, positioning_to_translation, add_translations, \
    rotate_xyz, rotation_matrix_to_euler


class XMLNode(Base):

    __icon__ = os.path.join(ICON_DIR, 'xml_tag.png')

    __initargs__ = ['element']

    element = Input()

    @Attribute
    def tag(self):
        return self.element.tag

    # override GUI label
    @Attribute
    def label(self):
        return self.tag

    @Input
    def value(self):
        val = self.element.text
        return val.strip() if val is not None else None

    @value.on_slot_change
    def _on_value_change(self, slot, new, old):
        self.set_element_value(new)

    @Attribute
    def attributes(self):
        return self.element.attrib

    @Attribute
    def child_elements(self):
        return self.element.getchildren()

    @Part
    def elements(self):
        return DynamicType(type=self.__class__,
                           quantify=len(self.child_elements),
                           element=self.child_elements[child.index],
                           suppress=len(self.child_elements) == 0)

    @Attribute
    def child_tags(self):
        return ([el.tag for el in self.elements]
                if self.elements is not Undefined else [])

    def set_attribute(self, name, value):
        # attribute set value, removes attribute if value is None
        if value is None:
            self.element.attrib.pop(name)
        else:
            self.element.attrib[name] = value
        self.get_cache('attributes').invalidate()

    def get_element_by_predicate(self, predicate, recursive=False):
        found = []
        if self.elements is not Undefined:
            for el in self.elements:
                if predicate(el):
                    found.append(el)
            if recursive:
                for el in self.elements:
                    found.extend(el.get_element_by_predicate(predicate, recursive=True))
        return found

    def get_element_by_attribute(self, attr, val, recursive=True):
        def p(el):
            return (attr in el.attributes and el.attributes[attr] == val) or \
                   (hasattr(el, attr) and getattr(el, attr) == val)
        return self.get_element_by_predicate(p, recursive=recursive)

    def get_node_by_element(self, el, recursive=False):
        return self.get_element_by_predicate(lambda n: n.element == el,
                                             recursive=recursive)

    def get_child_element(self, name):
        el = self.get_element_by_attribute('tag', name, recursive=False)
        return el

    def get_elements_by_name(self, name):
        el = self.get_element_by_attribute('tag', name, recursive=True)
        return el

    def set_element_value(self, val):
        self.element.text = val

    def set_element_attributes(self, attrib_dict):
        self.element.attrib = attrib_dict

    def create_child_element(self, tag, value=None, attributes=None):
        el = ET.SubElement(self.element, tag)
        if value is not None:
            el.text = str(value)
        if attributes is not None:
            el.attrib = attributes
        self.get_cache('_child_elements').invalidate()
        return self.get_node_by_element(el)[0]


class XMLFile(Base):

    __initargs__ = ['filepath']

    __icon__ = os.path.join(ICON_DIR, 'xml_doc.png')

    filepath = Input()
    save_filepath = Input(None)

    _node_type = XMLNode

    @Part
    def xml_root(self):
        return DynamicType(type=self._node_type,
                           element=self._root_element)

    @Attribute
    def _tree(self):
        return ET.parse(self.filepath)

    @Attribute
    def _root_element(self):
        return self._tree.getroot()

    def find_all(self, xpath):
        return [self.xml_root.get_node_by_element(el, True)[0]
                for el in self._tree.findall(xpath)]

    @Attribute
    def _file_dialog(self):
        return FileSaveDialog(filter="XML files|*.xml",
                              default_dir=os.path.basename(self.filepath))

    @action(label="Write XML file...")
    def write_file(self):
        if self.save_filepath is None:
            self.save_filepath = self._file_dialog.result
            self._file_dialog.refresh()
        if self.save_filepath is not None:
            self._tree.write(self.save_filepath)


class CPACSNode(XMLNode):

    @Attribute
    def uid(self):
        return self.attributes['uID'] if 'uID' in self.attributes else None

    @Part
    def elements(self):
        return DynamicType(type=self.__class__,
                           quantify=len(self.child_elements),
                           element=self.child_elements[child.index],
                           suppress=len(self.child_elements) == 0)

    @Input
    def value(self):
        val = super(CPACSNode, self).value
        if 'mapType' in self.attributes:
            val = parse_map(val, self.attributes['mapType'])
        elif val is not None:
            try:
                val = int(val) if '.' not in val else float(val)
            except ValueError:
                pass
        return val

    @value.on_slot_change
    def _on_value_change(self, slot, new, old):
        if 'mapType' in self.attributes:
            val = ';'.join(new)
        else:
            val = new
        self.set_element_value(val)

    @Attribute
    def points(self):
        if self.tag == 'pointList':
            return [Point(x, y, z)
                    for x, y, z in zip(*get_xyz(self))]
        else:
            return None

    @Attribute
    def transformation(self):
        if 'transformation' in self.child_tags:
            transformation = self.get_child_element('transformation')[0]
            data = map_elements(transformation.elements, get_xyz)
            if 'translation' in data:
                translation = transformation.get_child_element('translation')[0]
                if 'refType' in translation.attributes:
                    data['translationType'] = translation.attributes['refType']
                elif all(t==0 for t in data['translation']):
                    data['translationType'] = 'absGlobal'
                else:
                    data['translationType'] = 'absGlobal'  # todo
                    print('Invalid CPACS file: missing refType in translations')
            return data

    def get_element_by_uid(self, uid):
        return self.get_element_by_attribute('uID', uid)[0]

    def create_vector_child_element(self, tag, values, attributes=None):
        if attributes is None:
            attributes = {'mapType': 'vector'}
        else:
            attributes['mapType'] = 'vector'
        value_strs = [str(val) for val in values]
        return self.create_child_element(tag=tag,
                                         value=';'.join(value_strs),
                                         attributes=attributes)

    def create_point_list_child_element(self, pnts, tag='pointList'):
        el = self.create_child_element(tag)
        for dim, vals in zip(('x', 'y', 'z'), zip(*pnts)):
            el.create_vector_child_element(dim, vals)
        return el

    def create_transformation_child_element(self, translation=(0, 0, 0),
                                            rotation=(0, 0, 0),
                                            scaling=(1, 1, 1),
                                            ref_type='absLocal',
                                            tag='transformation'):

        el = self.create_child_element(tag, attributes={'refType': ref_type})
        for tag, values in zip(('translation', 'rotation', 'scaling'),
                               (translation, rotation, scaling)):
            sub_el = el.create_child_element(tag)
            for dim, value in zip(('x', 'y', 'z'), values):
                sub_el.create_child_element(dim, value)
        return el


class CPACSFile(XMLFile):

    _node_type = CPACSNode

    @Attribute
    def positionings(self):
        positionings = dict()
        for positioning in self.find_all('.//positioning'):
            child_element_tags = [child_element.tag for child_element in positioning.child_elements]
            if 'fromSectionUID' in child_element_tags:
                from_element = positioning.get_child_element('fromSectionUID')[0].value  # todo: make function?
            else:
                from_element = None
            to_element = positioning.get_child_element('toSectionUID')[0].value  #todo: change to zip function
            length = positioning.get_child_element('length')[0].value
            dihedral_angle = positioning.get_child_element('dihedralAngle')[0].value
            sweep_angle = positioning.get_child_element('sweepAngle')[0].value
            positionings[to_element] = {'from_element': from_element,
                                        'sweep': sweep_angle,
                                        'dihedral': dihedral_angle,
                                        'length': length}
        return positionings

    def get_element_by_uid(self, uid):
        return self.xml_root.get_element_by_uid(uid)

    def get_first_element(self, uid):
        """ This function returns the first element of a part, given the part's uID. The order of the elements is
        defined in the segments of the CPACS file
        """
        return self.get_element_by_uid(self.get_elements_order(uid)[0])

    def get_last_element(self, uid):
        return self.get_element_by_uid(self.get_elements_order(uid)[-1])

    def get_first_section(self, uid):
        return self.get_parent_element(self.get_parent_element(self.get_first_element(uid)))

    def get_elements_order(self, uid):
        """ Elements in this function or the elements in the sections of a part. The order of the elements is
        determined by the segments """
        part = self.get_element_by_uid(uid)
        segments = part.get_elements_by_name('segment')
        # Get segment information
        segment_info = []
        for segment in segments:
            from_element = segment.get_child_element('fromElementUID')[0].value
            to_element = segment.get_child_element('toElementUID')[0].value
            segment_info.append([from_element, to_element])
        # Order the segments to get an element chain
        element_chain = segment_info.pop(0)
        while segment_info:
            for segment in segment_info:
                if segment[1] == element_chain[0]:
                    element_chain = [segment[0]] + element_chain
                elif segment[0] == element_chain[-1]:
                    element_chain.append(segment[1])
                else:
                    continue
                del segment_info[segment_info.index(segment)]
                break
            else:
                raise IOError("Segments in part {} consists of two or more element "
                              "chains".format(part.get_child_element('name').value))
        return element_chain

    def get_positioning_translation(self, uid):
        """ Calculates the extra translation of a section due to positionings. """

        if uid in self.positionings:
            positioning = self.positionings[uid]
            translation = positioning_to_translation(positioning)
            origin = self.get_positioning_translation(positioning['from_element']) if \
                positioning['from_element'] in self.positionings else [0, 0, 0]
            return add_translations(origin, translation, 'absGlobal')
        else:
            return [0, 0, 0]

    def get_parent_element(self, element):
        all_possible_parents = self._tree.findall('.//{}/..'.format(element.element.tag))
        if len(all_possible_parents) == 1 and all_possible_parents[0] == self.xml_root.element:
            return self.xml_root
        for parent in all_possible_parents:
            for child in parent._children:  # todo: change
                if child == element.element:
                    return self.xml_root.get_node_by_element(parent, recursive=True)[0]

    def get_absolute_transformation(self, element):
        """ Function to calculate the total transformation of an element, including positioning of sections.
        The translation is always with respect to the global reference system ('absGlobal' in CPACS). If the
        translation with respect to a different reference system is needed use get_relative_transformation"""

        # Get parent transformation
        if element != self.xml_root:
            parent = self.get_parent_element(element)
            parent_transformation = self.get_absolute_transformation(parent)
        else:
            return {'scaling': [1.0, 1.0, 1.0],
                    'rotation': [0.0, 0.0, 0.0],
                    'translation': [0.0, 0.0, 0.0]}

        # Get positioning
        positioning_translation = None
        if 'uID' in element.attributes:
            uID = element.attributes['uID']
            if uID in self.positionings:
                positioning_translation = self.get_positioning_translation(uID)

        if positioning_translation:
            int_transformation = dict(parent_transformation)
            int_transformation['translation'] = add_translations(parent_transformation['translation'],
                                                                 positioning_translation,
                                                                 'absLocal',
                                                                 parent_transformation['rotation'])
        else:
            int_transformation = dict(parent_transformation)

        if element.transformation:
            return add_transformations(int_transformation, element.transformation)
        return int_transformation

    def get_relative_transformation(self, element, reference_system):
        """ Get the relative transformation with respect to a specified reference system. The input reference system
        must be a ParaPy Position"""  # todo: move this function to cpacs.py and name it relative_transformation here

        # Get the absolute transformation
        abs_transformation = self.get_absolute_transformation(element)
        total_rotation_matrix = np.array(zip(*rotate_xyz(XOY, abs_transformation['rotation']).orientation))

        # Get rotation of the reference system
        rotation_matrix = np.array(zip(*reference_system.orientation))
        # Take the inverse of the rotation matrix
        inv_rotation_matrix = np.linalg.inv(rotation_matrix)
        # Multiply with the rotation matrix of the abs transformation
        new_rotation_matrix = inv_rotation_matrix.dot(total_rotation_matrix)
        # Transfer the resulting rotation matrix to euler angles
        local_rotation = rotation_matrix_to_euler(new_rotation_matrix)

        # Get local translation
        translation_wrt_origin = [abs_transformation['translation'][i] - reference_system.location[i] for i in range(3)]
        # Multiply with unit vectors to get local translation
        local_translation = np.array(translation_wrt_origin).dot(np.array(zip(*reference_system.orientation)))

        return {'scaling': abs_transformation['scaling'],
                'rotation': local_rotation,
                'translation': local_translation}


def parse_map(value, map_type):
    if map_type == 'vector':
        return [float(el) for el in value.split(';')]
    else:
        ValueError("Unknown mapType: {}".format(map_type))


def get_xyz(el):
    return [el.get_child_element(dim)[0].value
            for dim in ('x', 'y', 'z')]


def map_elements(elements, fn):
    return {k: v for k, v in [(el.tag, fn(el))
                              for el in elements]}


if __name__ == '__main__':
    from parapy.gui import display
    xml_file = CPACSFile('Parsifal_MS1_CPACS.xml')
    display(xml_file)
