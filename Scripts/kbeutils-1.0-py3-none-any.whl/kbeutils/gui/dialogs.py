import wx
from parapy.core import Attribute, Input, Base

from kbeutils.gui.app import App


class Dialog(Base):

    title = Input()

    width = Input()
    height = Input()

    @Input
    def app(self):
        return App()

    @Attribute
    def _frame(self):
        app = self.app.wx_app  # make sure app is created
        frame = wx.Frame(None, -1, self.title)
        frame.SetDimensions(0, 0, self.width, self.height)
        return frame

    @Attribute
    def _dialog(self):
        raise NotImplementedError

    @Attribute
    def result(self):
        raise NotImplementedError


class FileDialog(Dialog):

    width = Input(200)
    height = Input(50)

    default_dir = Input("")
    default_file = Input("")

    filter = Input("All files|*.*")

    @Input
    def _wx_dialog_style(self):
        raise NotImplementedError

    @Attribute
    def _dialog(self):
        return wx.FileDialog(self._frame, self.title,
                             self.default_dir, self.default_file,
                             self.filter, self._wx_dialog_style)

    @Attribute
    def result(self):
        with self._dialog as dialog:
            if self._dialog.ShowModal() == wx.ID_CANCEL:
                selected_path = None
            else:
                selected_path = dialog.GetPath()

        self.get_cache('_dialog').invalidate()
        return selected_path

    def refresh(self):
        self.get_cache('result').invalidate()


class FileOpenDialog(FileDialog):

    title = Input("Select file...")
    _wx_dialog_style = Input(wx.FD_OPEN | wx.FD_FILE_MUST_EXIST)


class FileSaveDialog(FileDialog):
    title = Input("Enter file name...")
    _wx_dialog_style = Input(wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
