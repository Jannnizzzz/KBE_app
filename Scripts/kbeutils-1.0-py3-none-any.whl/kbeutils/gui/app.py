import wx
from parapy.core import Base, Attribute


class App(Base):
    @Attribute
    def wx_app(self):
        return wx.App()
