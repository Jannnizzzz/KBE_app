#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Description of the file
"""
from OCC.wrapper.ShapeAnalysis import ShapeAnalysis_Curve
from OCC.wrapper.gp import gp_XYZ
from parapy.geom import Curve
from parapy.geom.generic.positioning import orthogonal_vector


def is_straight_with_tolerance(self, tolerance: float = 0.0) -> bool:
    tangent = self.tangent1
    geom_curve = self.Handle_Geom_Curve
    normal = orthogonal_vector(tangent)
    if ShapeAnalysis_Curve.IsPlanar(

geom_curve, gp_XYZ(*normal), tolerance):
        bi_normal = normal.cross(tangent)
        return ShapeAnalysis_Curve.IsPlanar(
            geom_curve, gp_XYZ(*bi_normal), tolerance)
    return False


# TODO: Remove this patch once ParaPy version > 1.9.0 is released.
PATCH_IS_STRAIGHT_WITH_TOLERANCE = True
if PATCH_IS_STRAIGHT_WITH_TOLERANCE:
    Curve.is_straight_with_tolerance = is_straight_with_tolerance
