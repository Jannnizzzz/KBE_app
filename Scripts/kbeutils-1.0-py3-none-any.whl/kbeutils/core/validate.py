from collections import namedtuple

from parapy.core.validate import Validator


ValidatorValue = namedtuple('ValidatorValue', ('value', 'is_latebound'))


class LateBoundValidator(Validator):

    def __init__(self, parameter_dict, **kwargs):
        super(LateBoundValidator, self).__init__(**kwargs)
        self.parameters = {name: ValidatorValue(value, callable(value))
                           for name, value in parameter_dict.items()}

    def __getattr__(self, item):
        if hasattr(self, 'parameters') and item in self.parameters:
            return self.parameters[item].value

    def get_parameter(self, key, obj=None):
        if self.parameters[key].is_latebound:
            if obj is None:
                raise RuntimeError("supply obj")
            else:
                return self.parameters[key].value(obj)
        else:
            return self.parameters[key].value

    def call(self, value, obj, slot):
        params = {key: self.get_parameter(key, obj)
                  for key in self.parameters.keys()}
        return self._fn(**params)(value)

    @staticmethod
    def _fn(**kwargs):
        raise NotImplementedError


class LengthInRange(LateBoundValidator):

    def __init__(self, lower, upper, **kwargs):
        super(LengthInRange, self).__init__({'lower': lower,
                                             'upper': upper}, **kwargs)

    @staticmethod
    def _fn(lower, upper):
        return lambda slot: lower <= len(slot) <= upper

    def __repr__(self):
        return "{} <= length <= {}".format(self.lower, self.upper)


class LengthEqualTo(LateBoundValidator):

    def __init__(self, length, **kwargs):
        super(LengthEqualTo, self).__init__({'length': length}, **kwargs)

    @staticmethod
    def _fn(length):
        return lambda slot: len(slot) == length

    def __repr__(self):
        return "length == {}".format(self.length)