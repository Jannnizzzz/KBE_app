import numpy as np

eps = np.finfo(float).eps